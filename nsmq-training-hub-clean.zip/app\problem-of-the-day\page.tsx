"use client";

import { useEffect, useState } from "react";
import { ClipboardCheck } from "lucide-react";
import { PageHeading } from "@/components/page-heading";
import { PracticeRunner } from "@/components/practice-runner";
import type { Question } from "@/lib/types";

export default function ProblemPage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  useEffect(() => { fetch("/api/questions?roundType=PROBLEM_OF_THE_DAY&limit=1").then((response) => response.json()).then(setQuestions); }, []);
  return (
    <div className="page-shell">
      <PageHeading eyebrow="Round 3" title="Problem of the Day" description="Set out your thinking clearly. For the MVP, your final answer is checked automatically and a coach can award method marks manually." />
      {questions[0] && <div className="mb-4 max-w-4xl rounded-2xl border border-gold/30 bg-amber-50 p-4 text-sm"><p className="flex items-center gap-2 font-bold"><ClipboardCheck size={18} /> What examiners are testing</p><p className="mt-1 text-ink/65">{questions[0].examinerFocus}</p><p className="mt-2 font-semibold">Marking scheme: {questions[0].markingScheme}</p></div>}
      <div className="max-w-4xl"><PracticeRunner questions={questions} mode="PROBLEM_OF_THE_DAY" timed={false} /></div>
    </div>
  );
}
