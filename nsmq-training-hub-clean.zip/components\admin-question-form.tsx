"use client";

import { useState } from "react";
import { DIFFICULTIES, PERMISSION_STATUSES, ROUND_TYPES, SOURCE_TYPES, SUBJECTS } from "@/lib/constants";

const initial = {
  subject: "MATHEMATICS", topic: "", subtopic: "", roundType: "ROUND_ONE", difficulty: "MEDIUM",
  timeLimitSeconds: 30, questionText: "", answer: "", acceptedAnswers: "[]", shortcutSolution: "",
  fullSolution: "", commonTrap: "", encouragement: "You missed the pattern, not the whole topic. Try 3 more from this pattern.",
  repeatedPattern: "", patternFamily: "", sourceType: "ORIGINAL", sourceName: "", sourceUrl: "",
  sourceYear: "", contestStage: "", videoTimestamp: "", permissionStatus: "ORIGINAL", tags: "[]",
};

export function AdminQuestionForm({ onSaved }: { onSaved?: () => void }) {
  const [form, setForm] = useState<Record<string, string | number>>(initial);
  const [message, setMessage] = useState("");
  const field = (name: string) => ({ value: form[name], onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setForm({ ...form, [name]: event.target.value }) });
  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    const response = await fetch("/api/questions", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    setMessage(response.ok ? "Question added to the bank." : "Could not save this question.");
    if (response.ok) { setForm(initial); onSaved?.(); }
  };
  return (
    <form className="panel p-5 sm:p-7" onSubmit={submit}>
      <h2 className="font-display text-2xl font-semibold">Add a question</h2>
      <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <label className="text-sm font-bold">Subject<select className="field" {...field("subject")}>{SUBJECTS.map((value) => <option key={value}>{value}</option>)}</select></label>
        <label className="text-sm font-bold">Topic<input required className="field" {...field("topic")} /></label>
        <label className="text-sm font-bold">Subtopic<input required className="field" {...field("subtopic")} /></label>
        <label className="text-sm font-bold">Round type<select className="field" {...field("roundType")}>{ROUND_TYPES.map((value) => <option key={value}>{value}</option>)}</select></label>
        <label className="text-sm font-bold">Difficulty<select className="field" {...field("difficulty")}>{DIFFICULTIES.map((value) => <option key={value}>{value}</option>)}</select></label>
        <label className="text-sm font-bold">Time limit (seconds)<input className="field" type="number" min="1" {...field("timeLimitSeconds")} /></label>
        <label className="text-sm font-bold sm:col-span-2 lg:col-span-3">Question<textarea required className="field min-h-24" {...field("questionText")} /></label>
        <label className="text-sm font-bold">Answer<input required className="field" {...field("answer")} /></label>
        <label className="text-sm font-bold">Accepted answers (JSON array)<input className="field" placeholder='["24", "24 m/s"]' {...field("acceptedAnswers")} /></label>
        <label className="text-sm font-bold">Tags (JSON array)<input className="field" placeholder='["motion", "kinematics"]' {...field("tags")} /></label>
        {["shortcutSolution", "fullSolution", "commonTrap", "encouragement"].map((name) => <label key={name} className="text-sm font-bold sm:col-span-2 lg:col-span-3">{name.replace(/([A-Z])/g, " $1")}<textarea required className="field min-h-20" {...field(name)} /></label>)}
        <label className="text-sm font-bold">Repeated pattern<input required className="field" {...field("repeatedPattern")} /></label>
        <label className="text-sm font-bold">Pattern family<input required className="field" {...field("patternFamily")} /></label>
        <label className="text-sm font-bold">Source type<select className="field" {...field("sourceType")}>{SOURCE_TYPES.map((value) => <option key={value}>{value}</option>)}</select></label>
        <label className="text-sm font-bold">Source name<input className="field" {...field("sourceName")} /></label>
        <label className="text-sm font-bold">Source URL<input className="field" type="url" {...field("sourceUrl")} /></label>
        <label className="text-sm font-bold">Source year<input className="field" type="number" {...field("sourceYear")} /></label>
        <label className="text-sm font-bold">Contest stage<input className="field" {...field("contestStage")} /></label>
        <label className="text-sm font-bold">Video timestamp<input className="field" {...field("videoTimestamp")} /></label>
        <label className="text-sm font-bold">Permission status<select className="field" {...field("permissionStatus")}>{PERMISSION_STATUSES.map((value) => <option key={value}>{value}</option>)}</select></label>
      </div>
      <div className="mt-6 flex items-center gap-4"><button className="button-primary" type="submit">Save question</button>{message && <p className="text-sm font-bold text-chemistry">{message}</p>}</div>
    </form>
  );
}
