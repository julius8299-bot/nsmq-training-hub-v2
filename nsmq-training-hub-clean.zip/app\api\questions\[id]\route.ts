import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await request.json();
  delete body.id;
  delete body.createdAt;
  delete body.updatedAt;
  delete body.riddleClues;
  const question = await prisma.question.update({
    where: { id },
    data: {
      ...body,
      timeLimitSeconds: Number(body.timeLimitSeconds),
      sourceYear: body.sourceYear ? Number(body.sourceYear) : null,
      numericTolerance: body.numericTolerance ? Number(body.numericTolerance) : null,
    },
  });
  return NextResponse.json(question);
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await prisma.question.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
