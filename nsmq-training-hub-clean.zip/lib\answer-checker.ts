const normalize = (value: string) =>
  value
    .trim()
    .toLowerCase()
    .replace(/[,\s]+/g, " ")
    .replace(/[.]+$/, "");

const normalizeBoolean = (value: string) => {
  const normalized = normalize(value);
  if (normalized === "t") return "true";
  if (normalized === "f") return "false";
  return normalized;
};

const parseNumeric = (value: string) => {
  const cleaned = value.replace(/,/g, "").trim();
  const match = cleaned.match(/^(-?\d+(?:\.\d+)?)(?:\s*[a-zA-Z/%°²³-]+)?$/);
  return match ? Number(match[1]) : null;
};

export function checkAnswer(
  userAnswer: string,
  answer: string,
  acceptedAnswers: string,
  tolerance?: number | null,
) {
  let alternatives: string[] = [];
  try {
    alternatives = JSON.parse(acceptedAnswers || "[]");
  } catch {
    alternatives = acceptedAnswers.split("|").filter(Boolean);
  }

  const expected = [answer, ...alternatives];
  const normalizedUser = normalizeBoolean(userAnswer);

  if (expected.some((item) => normalizeBoolean(String(item)) === normalizedUser)) return true;

  const userNumber = parseNumeric(userAnswer);
  if (userNumber === null) return false;

  return expected.some((item) => {
    const expectedNumber = parseNumeric(String(item));
    if (expectedNumber === null) return false;
    const allowed = tolerance ?? Math.max(Math.abs(expectedNumber) * 0.005, 0.01);
    return Math.abs(userNumber - expectedNumber) <= allowed;
  });
}
