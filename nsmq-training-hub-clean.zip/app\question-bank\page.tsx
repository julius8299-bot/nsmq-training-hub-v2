"use client";

import { useEffect, useState } from "react";
import { Search } from "lucide-react";
import { DifficultyFilter, RoundSelector, SubjectFilter } from "@/components/filters";
import { PageHeading } from "@/components/page-heading";
import { ROUND_LABELS, SOURCE_TYPES, SUBJECT_STYLES } from "@/lib/constants";
import type { Question } from "@/lib/types";

export default function QuestionBankPage() {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState("");
  const [roundType, setRoundType] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [sourceType, setSourceType] = useState("");
  const [pattern, setPattern] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    const params = new URLSearchParams({ limit: "100", ...(search && { search }), ...(subject && { subject }), ...(roundType && { roundType }), ...(difficulty && { difficulty }), ...(sourceType && { sourceType }), ...(pattern && { repeatedPattern: pattern }) });
    const timeout = window.setTimeout(() => fetch(`/api/questions?${params}`).then((response) => response.json()).then(setQuestions), 150);
    return () => window.clearTimeout(timeout);
  }, [search, subject, roundType, difficulty, sourceType, pattern]);

  return (
    <div className="page-shell">
      <PageHeading eyebrow="Study the patterns" title="Question Bank" description="Search original and properly tracked practice material. Open any question to study its answer, shortcut, and full reasoning." />
      <div className="panel mb-6 grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-6">
        <label className="relative sm:col-span-2"><Search className="absolute left-3 top-3 text-ink/35" size={18} /><input className="field pl-10" placeholder="Search questions or tags" value={search} onChange={(event) => setSearch(event.target.value)} /></label>
        <SubjectFilter value={subject} onChange={setSubject} includeAll />
        <RoundSelector value={roundType} onChange={setRoundType} includeAll />
        <DifficultyFilter value={difficulty} onChange={setDifficulty} includeAll />
        <select className="field" value={sourceType} onChange={(event) => setSourceType(event.target.value)}><option value="">All sources</option>{SOURCE_TYPES.map((value) => <option key={value}>{value}</option>)}</select>
        <input className="field lg:col-span-2" placeholder="Repeated pattern" value={pattern} onChange={(event) => setPattern(event.target.value)} />
      </div>
      <p className="mb-4 text-sm font-bold text-ink/50">{questions.length} question{questions.length === 1 ? "" : "s"} found</p>
      <div className="grid gap-4">
        {questions.map((question) => {
          const style = SUBJECT_STYLES[question.subject];
          return (
            <article key={question.id} className="panel overflow-hidden">
              <button type="button" className="w-full p-5 text-left" onClick={() => setOpenId(openId === question.id ? null : question.id)}>
                <div className="flex flex-wrap gap-2 text-xs font-bold uppercase"><span className={`${style.bg} ${style.text} rounded-full px-2.5 py-1`}>{question.subject}</span><span className="rounded-full bg-ink/5 px-2.5 py-1">{ROUND_LABELS[question.roundType]}</span><span className="rounded-full bg-ink/5 px-2.5 py-1">{question.difficulty.replaceAll("_", " ")}</span></div>
                <h2 className="mt-3 font-display text-xl font-semibold">{question.questionText}</h2>
                <p className="mt-2 text-sm text-ink/45">{question.topic} · {question.subtopic} · Pattern: {question.repeatedPattern}</p>
              </button>
              {openId === question.id && <div className="grid gap-3 border-t border-ink/10 bg-ink/[0.02] p-5 md:grid-cols-3"><div><p className="eyebrow">Answer</p><p className="mt-2 font-bold">{question.answer}</p></div><div><p className="eyebrow">Shortcut</p><p className="mt-2 text-sm leading-6">{question.shortcutSolution}</p></div><div><p className="eyebrow">Full solution</p><p className="mt-2 text-sm leading-6">{question.fullSolution}</p></div></div>}
            </article>
          );
        })}
      </div>
    </div>
  );
}
