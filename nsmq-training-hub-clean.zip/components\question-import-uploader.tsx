"use client";

import Papa from "papaparse";
import { FileJson, FileSpreadsheet, Upload } from "lucide-react";
import { useState } from "react";

export function QuestionImportUploader({ onImported }: { onImported?: () => void }) {
  const [status, setStatus] = useState("");

  const upload = async (file: File) => {
    setStatus("Reading file…");
    let rows: Record<string, unknown>[] = [];
    if (file.name.toLowerCase().endsWith(".json")) {
      const parsed = JSON.parse(await file.text());
      rows = Array.isArray(parsed) ? parsed : [parsed];
    } else {
      const parsed = Papa.parse<Record<string, unknown>>(await file.text(), { header: true, skipEmptyLines: true });
      rows = parsed.data;
    }

    let saved = 0;
    for (const row of rows) {
      const response = await fetch("/api/questions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...row,
          acceptedAnswers: typeof row.acceptedAnswers === "string" ? row.acceptedAnswers : JSON.stringify(row.acceptedAnswers || []),
          tags: typeof row.tags === "string" ? row.tags : JSON.stringify(row.tags || []),
        }),
      });
      if (response.ok) saved += 1;
    }
    setStatus(`${saved} of ${rows.length} questions imported.`);
    onImported?.();
  };

  return (
    <div className="panel p-5 sm:p-7">
      <div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-gold/20 text-ink"><Upload size={19} /></span><div><h2 className="font-display text-2xl font-semibold">Bulk import</h2><p className="text-sm text-ink/50">CSV or JSON, with source metadata preserved.</p></div></div>
      <label className="mt-5 flex cursor-pointer flex-col items-center rounded-2xl border-2 border-dashed border-ink/15 p-8 text-center transition hover:border-chemistry hover:bg-emerald-50">
        <span className="flex gap-2 text-ink/45"><FileSpreadsheet /><FileJson /></span>
        <span className="mt-3 font-bold">Choose a CSV or JSON file</span>
        <span className="mt-1 text-xs text-ink/45">Every sourced question must include permissionStatus.</span>
        <input className="hidden" type="file" accept=".csv,.json,application/json,text/csv" onChange={(event) => event.target.files?.[0] && upload(event.target.files[0])} />
      </label>
      {status && <p className="mt-3 text-sm font-bold text-chemistry">{status}</p>}
    </div>
  );
}
