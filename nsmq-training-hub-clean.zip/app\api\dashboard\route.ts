import { NextResponse } from "next/server";
import { SUBJECTS } from "@/lib/constants";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const user = await prisma.user.findUnique({ where: { email: "student@nsmqhub.local" } });
  const attempts = user
    ? await prisma.attempt.findMany({
        where: { userId: user.id },
        include: { question: true },
        orderBy: { createdAt: "desc" },
      })
    : [];

  const subjects = SUBJECTS.map((subject) => {
    const items = attempts.filter((attempt) => attempt.question.subject === subject);
    const correct = items.filter((attempt) => attempt.isCorrect).length;
    const topicStats = new Map<string, { total: number; correct: number }>();
    items.forEach((attempt) => {
      const current = topicStats.get(attempt.question.topic) ?? { total: 0, correct: 0 };
      current.total += 1;
      current.correct += attempt.isCorrect ? 1 : 0;
      topicStats.set(attempt.question.topic, current);
    });
    const sorted = [...topicStats.entries()].sort(
      (a, b) => b[1].correct / b[1].total - a[1].correct / a[1].total,
    );
    return {
      subject,
      attempted: items.length,
      accuracy: items.length ? Math.round((correct / items.length) * 100) : 0,
      strongestTopic: sorted[0]?.[0] ?? "Start training",
      weakestTopic: sorted.at(-1)?.[0] ?? "No data yet",
    };
  });

  let streak = 0;
  for (const attempt of attempts) {
    if (!attempt.isCorrect) break;
    streak += 1;
  }

  const problem = await prisma.question.findFirst({
    where: { roundType: "PROBLEM_OF_THE_DAY" },
    orderBy: { createdAt: "asc" },
  });

  return NextResponse.json({
    attempts: attempts.length,
    accuracy: attempts.length
      ? Math.round((attempts.filter((attempt) => attempt.isCorrect).length / attempts.length) * 100)
      : 0,
    streak,
    subjects,
    problem,
  });
}
