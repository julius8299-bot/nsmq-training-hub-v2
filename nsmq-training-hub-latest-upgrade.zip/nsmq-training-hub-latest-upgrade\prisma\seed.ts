import { PrismaClient } from "@prisma/client";
import { mathematicsQuestions } from "./seed-data/mathematics";
import { physicsQuestions } from "./seed-data/physics";
import { chemistryQuestions } from "./seed-data/chemistry";
import { biologyQuestions } from "./seed-data/biology";
import { supplementalPatternQuestions } from "./seed-data/supplemental-patterns";
import { validateQuestions, type SeedQuestion } from "./seed-data/question-factory";

const prisma = new PrismaClient();
const questions = [
  ...mathematicsQuestions,
  ...physicsQuestions,
  ...chemistryQuestions,
  ...biologyQuestions,
  ...supplementalPatternQuestions,
];

function databaseRow(question: SeedQuestion) {
  const { riddleClues: _riddleClues, acceptedAnswers, tags, ...data } = question;
  return {
    ...data,
    acceptedAnswers: JSON.stringify(acceptedAnswers),
    tags: JSON.stringify(tags),
    sourceName: "NSMQ Training Hub original question factory",
  };
}

async function createInChunks<T>(rows: T[], create: (chunk: T[]) => Promise<unknown>, size = 400) {
  for (let index = 0; index < rows.length; index += size) {
    await create(rows.slice(index, index + size));
  }
}

async function main() {
  validateQuestions(questions);

  await prisma.attempt.deleteMany();
  await prisma.riddleClue.deleteMany();
  await prisma.question.deleteMany();
  await prisma.topic.deleteMany();
  await prisma.user.deleteMany();

  await prisma.user.createMany({
    data: [
      { name: "Demo Student", email: "student@nsmqhub.local", role: "STUDENT" },
      { name: "Demo Coach", email: "coach@nsmqhub.local", role: "COACH" },
    ],
  });

  const standardQuestions = questions.filter((question) => question.roundType !== "RIDDLE");
  await createInChunks(
    standardQuestions.map(databaseRow),
    (data) => prisma.question.createMany({ data }),
  );

  for (const question of questions.filter((item) => item.roundType === "RIDDLE")) {
    await prisma.question.create({
      data: {
        ...databaseRow(question),
        riddleClues: { create: question.riddleClues! },
      },
    });
  }

  const uniqueTopics = [
    ...new Map(
      questions.map((item) => [
        `${item.subject}:${item.topic}`,
        {
          subject: item.subject,
          name: item.topic,
          description: `Practice ${item.topic.toLowerCase()} patterns for ${item.subject.toLowerCase()}.`,
        },
      ]),
    ).values(),
  ];
  await prisma.topic.createMany({ data: uniqueTopics });

  const count = (field: keyof SeedQuestion, value: string | boolean) =>
    questions.filter((question) => question[field] === value).length;

  console.log("NSMQ Training Hub seed complete");
  console.log(`Total questions: ${questions.length}`);
  console.log(`Mathematics: ${count("subject", "MATHEMATICS")}`);
  console.log(`Physics: ${count("subject", "PHYSICS")}`);
  console.log(`Chemistry: ${count("subject", "CHEMISTRY")}`);
  console.log(`Biology: ${count("subject", "BIOLOGY")}`);
  console.log(`Ghana-context: ${count("ghanaContext", true)}`);
  console.log(`Round 1: ${count("roundType", "ROUND_ONE")}`);
  console.log(`Speed Race: ${count("roundType", "SPEED_RACE")}`);
  console.log(`Problem of the Day: ${count("roundType", "PROBLEM_OF_THE_DAY")}`);
  console.log(`True/False: ${count("roundType", "TRUE_FALSE")}`);
  console.log(`Riddles: ${count("roundType", "RIDDLE")}`);
  console.log(`Easy: ${count("difficulty", "EASY")}`);
  console.log(`Medium: ${count("difficulty", "MEDIUM")}`);
  console.log(`Hard: ${count("difficulty", "HARD")}`);
  console.log(`NSMQ Final Level: ${count("difficulty", "NSMQ_FINAL_LEVEL")}`);
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
